-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2023 at 01:16 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `klinik-ci-3`
--

-- --------------------------------------------------------

--
-- Table structure for table `berobat`
--

CREATE TABLE `berobat` (
  `id_berobat` int(11) NOT NULL,
  `id_pasien` int(11) NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `tgl_berobat` date NOT NULL,
  `keluhan` text NOT NULL,
  `diagnosa` varchar(100) NOT NULL,
  `penatalaksaan` enum('-','Dalam Kota','Luar Kota','Kabupaten','Lainnya') NOT NULL,
  `peserta` enum('-','PBI (APBN)','PBI (APBD)','Non PBI','Lainnya') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `berobat`
--

INSERT INTO `berobat` (`id_berobat`, `id_pasien`, `id_dokter`, `tgl_berobat`, `keluhan`, `diagnosa`, `penatalaksaan`, `peserta`) VALUES
(41, 70, 20, '2023-05-01', '', 'Poli Mata', 'Dalam Kota', 'Non PBI'),
(42, 71, 21, '2023-05-02', '', 'Poli Umum', 'Luar Kota', 'PBI (APBN)'),
(43, 72, 22, '2023-05-03', '', 'Poli Umum', 'Kabupaten', 'Non PBI'),
(44, 73, 23, '2023-05-04', '', 'Konservasi', 'Dalam Kota', 'PBI (APBD)'),
(45, 74, 24, '2023-05-05', '', 'Konservasi', 'Luar Kota', 'Non PBI'),
(46, 75, 25, '2023-05-06', '', 'Poli Umum', 'Luar Kota', 'Non PBI'),
(47, 76, 26, '2023-05-09', '', 'Konservasi', 'Luar Kota', 'PBI (APBD)'),
(48, 77, 27, '2023-05-11', '', 'Konservasi', 'Luar Kota', 'PBI (APBN)'),
(49, 78, 28, '2023-05-13', '', 'Poli Mata', 'Dalam Kota', 'Non PBI'),
(50, 79, 29, '2023-05-21', '', 'Poli Umum', 'Dalam Kota', 'PBI (APBD)'),
(51, 80, 30, '2023-05-23', '', 'Konservasi', 'Dalam Kota', 'Non PBI');

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `id_dokter` int(11) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `nama_dokter` varchar(50) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jk_dokter` enum('L','P') NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `spesialis` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `nip`, `nama_dokter`, `tempat_lahir`, `tanggal_lahir`, `jk_dokter`, `jabatan`, `pendidikan`, `spesialis`) VALUES
(20, '10001', 'Dr. Fauzan', 'Sidoarjo', '1986-01-01', 'L', 'Staff Medis', 'S1 Kodokteran', 'Spesialis Jantung'),
(21, '10002', 'Dr. Bella Hadid', 'Jombang', '1989-02-02', 'P', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Mata'),
(22, '10003', 'Dr. Indrawan', 'Lampung', '1987-03-05', 'L', 'Staff Medis', 'S1 Kodokteran', 'Spesialis Ortopedi'),
(23, '10004', 'Dr. Nina Tamami', 'Maluku', '1987-04-30', 'P', 'Staff Medis', 'S1 Kodokteran', 'Spesialis Paru'),
(24, '10005', 'Dr. Zalina Ashar', 'Bengkulu', '1986-05-17', 'P', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Kulit'),
(25, '10006', 'Dr. Fadly', 'Jakarta', '1987-06-14', 'L', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Organ Dalam'),
(26, '10007', 'Dr. Nizam Erha', 'Mojokerto', '1992-07-01', 'L', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Mata'),
(27, '10008', 'Dr. Fita Sari', 'Pasuruan', '1994-04-27', 'P', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Kulit dan Kelamin'),
(28, '10009', 'Dr. Reyhan Ahmad', 'Probolinggo', '1993-04-29', 'L', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Liver'),
(29, '10010', 'Dr. Vivi Nur Hidayati', 'Sidoarjo', '1994-02-14', 'P', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Otak'),
(30, '10011', 'Dr. Reva Juwita', 'Lamongan', '1993-07-30', 'P', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Ortopedi'),
(31, '10012', 'Dr. Nurmuslimah', 'Surabaya', '1988-08-19', 'P', 'Staff Medis', 'S1 Kedokteran', 'Spesialis Ginjal');

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE `obat` (
  `id_obat` int(11) NOT NULL,
  `nama_obat` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`id_obat`, `nama_obat`) VALUES
(2, 'Oral Surgery'),
(4, 'Konservasi');

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE `pasien` (
  `id_pasien` int(11) NOT NULL,
  `no_rm` varchar(30) NOT NULL,
  `nama_pasien` varchar(50) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `umur_pasien` int(11) NOT NULL,
  `jk_pasien` enum('L','P') NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `agama` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `kecamatan` varchar(50) NOT NULL,
  `kelurahan` varchar(50) NOT NULL,
  `kabupaten` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `gol_darah` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`id_pasien`, `no_rm`, `nama_pasien`, `tempat_lahir`, `tanggal_lahir`, `umur_pasien`, `jk_pasien`, `pendidikan`, `agama`, `pekerjaan`, `alamat`, `kecamatan`, `kelurahan`, `kabupaten`, `status`, `gol_darah`) VALUES
(70, '20001', 'Samsul Bahri', 'Madura', '1991-12-31', 31, 'L', 'S1 Teknik Sipil', 'Islam', 'Mandor Bangunan', 'Surabaya', 'Semolowaru', 'Semolowaru', 'Surabaya', 'Belum Nikah', 'A'),
(71, '20002', 'Arif Kusuma', 'Jombang', '1990-11-01', 32, 'L', 'S1 Teknik Mesin', 'Kristen', 'Tukang Bubut', 'Sidoarjo', 'Candi', 'Candi', 'Sidoarjo', 'Menikah', 'B'),
(72, '20003', 'Zulham', 'Surabaya', '1992-10-01', 30, 'L', 'SMA', 'Hindu', 'Wiraswasta', 'Surabaya', 'Wiyung', 'Wiyung', 'Surabaya', 'Menikah', 'O'),
(73, '20004', 'Solikha', 'Sidoarjo', '1989-10-25', 33, 'P', 'SMP', 'Islam', 'Ibu rumah tangga', 'Barata Jaya', 'Gubeng', 'Gubeng', 'Surabaya', 'Menikah', 'AB'),
(74, '20005', 'Ayu Widia', 'Sidoarjo', '1992-02-22', 30, 'P', 'S1 Psikologi', 'Islam', 'HRD', 'Waru', 'Waru', 'Waru', 'Sidoarjo', 'Belum Nikah', 'A'),
(75, '20006', 'Farah Mahdiyah', 'Sidoarjo', '1995-11-01', 27, 'P', 'SMA', 'Islam', 'Supervisor Marketing', 'Gedangan', 'Gedangan', 'Gedangan', 'Sidoarjo', 'Belum Nikah', 'O'),
(76, '20007', 'Ahmad Basri', 'Lamongan', '1993-09-23', 29, 'L', 'S1 Sastra Inggris', 'Islam', 'Wiraswasta', 'Larangan', 'Larangan', 'Larangan', 'Sidoarjo', 'Belum Nikah', 'A'),
(77, '20008', 'Ilena Tio', 'Surabaya', '1990-08-27', 32, 'P', 'S1 Fisika', 'Islam', 'Ibu rumah tangga', 'Gedangan', 'Gedangan', 'Gedangan', 'Sidoarjo', 'Menikah', 'O'),
(78, '20009', 'Irawati Dewi', 'Bandung', '1992-04-02', 30, 'P', 'SMP', 'Islam', 'Wiraswasta', 'Surabaya', 'Semolowaru', 'Semolowaru', 'Surabaya', 'Cerai', 'AB'),
(79, '20010', 'Nina Tamami', 'Sidoarjo', '1995-06-07', 26, 'P', 'SMA', 'Budha', 'Wiraswasta', 'Gubeng', 'Gubeng', 'Gubeng', 'Surabaya', 'Belum Nikah', 'O'),
(80, '20011', 'Sandhy Pradipta', 'Bojonegoro', '1994-05-05', 28, 'L', 'S1 Teknik Informatika', 'Islam', 'Wiraswasta', 'Semolowaru Utara', 'Semolowaru', 'Semolowaru', 'Surabaya', 'Menikah', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `resep_obat`
--

CREATE TABLE `resep_obat` (
  `id_resep` int(11) NOT NULL,
  `id_berobat` int(11) NOT NULL,
  `id_obat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(256) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `nama_lengkap`) VALUES
(3, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Nakula'),
(8, 'sadewa', 'fbdc67e488677d811f7784b29ba4c8c87c87f74c', 'Sadewa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berobat`
--
ALTER TABLE `berobat`
  ADD PRIMARY KEY (`id_berobat`),
  ADD KEY `id_dokter` (`id_dokter`),
  ADD KEY `id_pasien` (`id_pasien`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indexes for table `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id_pasien`);

--
-- Indexes for table `resep_obat`
--
ALTER TABLE `resep_obat`
  ADD PRIMARY KEY (`id_resep`),
  ADD KEY `id_obat` (`id_obat`),
  ADD KEY `id_berobat` (`id_berobat`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berobat`
--
ALTER TABLE `berobat`
  MODIFY `id_berobat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `obat`
--
ALTER TABLE `obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `resep_obat`
--
ALTER TABLE `resep_obat`
  MODIFY `id_resep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `berobat`
--
ALTER TABLE `berobat`
  ADD CONSTRAINT `berobat_ibfk_1` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON UPDATE CASCADE,
  ADD CONSTRAINT `berobat_ibfk_2` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id_pasien`);

--
-- Constraints for table `resep_obat`
--
ALTER TABLE `resep_obat`
  ADD CONSTRAINT `resep_obat_ibfk_1` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`) ON DELETE CASCADE,
  ADD CONSTRAINT `resep_obat_ibfk_2` FOREIGN KEY (`id_berobat`) REFERENCES `berobat` (`id_berobat`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
