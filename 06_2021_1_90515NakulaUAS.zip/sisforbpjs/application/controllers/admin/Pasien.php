<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Pasien_m');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$page = @$_GET["page"]?@$_GET["page"]:1;
		$perpage = @$_GET["perpage"]?@$_GET["perpage"]:10;
		$data['title'] = 'Manajemen Data Pasien';
		$data['rowcount']=$this->db->count_all_results('pasien');
		$data['pasien'] = $this->Pasien_m->getPagination('pasien',$page,$perpage)->result_array();
		$this->form_validation->set_rules('no_rm', 'Nomer RM', 'required|trim');
		$this->form_validation->set_rules('nama', 'Nama Pasien', 'required|trim');
		$this->form_validation->set_rules('tempat_lahir', 'Tempat Lahir', 'required|trim');
		$this->form_validation->set_rules('tgl', 'Tanggal Lahir', 'required|trim');
		$this->form_validation->set_rules('jk', 'Kelamin Pasien', 'required|trim');
		$this->form_validation->set_rules('umur', 'Umur Pasien', 'required|trim');
		$this->form_validation->set_rules('pendidikan', 'Pendidikan', 'required|trim');
		$this->form_validation->set_rules('agama', 'Agama', 'required|trim');
		$this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required|trim');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
		$this->form_validation->set_rules('kecamatan', 'Kecamatan', 'required|trim');
		$this->form_validation->set_rules('kelurahan', 'Kelurahan', 'required|trim');
		$this->form_validation->set_rules('kabupaten', 'Kabupaten', 'required|trim');
		$this->form_validation->set_rules('status', 'Status Perkawinan', 'required|trim');
		$this->form_validation->set_rules('gol_darah', 'Golongan Darah', 'required|trim');
		// $this->form_validation->set_rules('asal_rujukan', 'Asal Rujukan', 'required|trim');
		if($this->form_validation->run() == FALSE) {
			$this->load->view('layout/header', $data);
			$this->load->view('layout/sidebar');
			$this->load->view('admin/pasien/index', $data);
			$this->load->view('layout/footer');
		} else {
			$data = [
				'no_rm' => html_escape($this->input->post('no_rm', true)),
				'nama_pasien' => html_escape($this->input->post('nama', true)),
				'tempat_lahir' => html_escape($this->input->post('tempat_lahir', true)),
				'tanggal_lahir' => html_escape($this->input->post('tgl', true)),
				'jk_pasien' => html_escape($this->input->post('jk', true)),
				'umur_pasien' => html_escape($this->input->post('umur', true)),
				'pendidikan' => html_escape($this->input->post('pendidikan', true)),
				'agama' => html_escape($this->input->post('agama', true)),
				'pekerjaan' => html_escape($this->input->post('pekerjaan', true)),
				'alamat' => html_escape($this->input->post('alamat', true)),
				'kecamatan' => html_escape($this->input->post('kecamatan', true)),
				'kelurahan' => html_escape($this->input->post('kelurahan', true)),
				'kabupaten' => html_escape($this->input->post('kabupaten', true)),
				'status' => html_escape($this->input->post('status', true)),
				'gol_darah' => html_escape($this->input->post('gol_darah', true))
				// 'asal_rujukan' => html_escape($this->input->post('asal_rujukan', true))
			];
			$this->Pasien_m->tambahDataPasien($data);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert"><i class="fas fa-info-circle"></i> Pasien Berhasil Ditambahkan.</div>');
			redirect('admin/pasien');
		}
	}

	public function ubah($id)
	{
		$data['title'] = 'Ubah Data Pasien';
		$where = ['id_pasien' => $id];
		$data['pasien'] = $this->Pasien_m->get_where('pasien', $where)->row_array();
		$this->form_validation->set_rules('no_rm', 'Nomer RM', 'required|trim');
		$this->form_validation->set_rules('nama', 'Nama Pasien', 'required|trim');
		$this->form_validation->set_rules('tempat_lahir', 'Tempat Lahir', 'required|trim');
		$this->form_validation->set_rules('tgl', 'Tanggal Lahir', 'required|trim');
		$this->form_validation->set_rules('jk', 'Kelamin Pasien', 'required|trim');
		$this->form_validation->set_rules('umur', 'Umur Pasien', 'required|trim');
		$this->form_validation->set_rules('pendidikan', 'Pendidikan', 'required|trim');
		$this->form_validation->set_rules('agama', 'Agama', 'required|trim');
		$this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required|trim');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
		$this->form_validation->set_rules('kecamatan', 'Kecamatan', 'required|trim');
		$this->form_validation->set_rules('kelurahan', 'Kelurahan', 'required|trim');
		$this->form_validation->set_rules('kabupaten', 'Kabupaten', 'required|trim');
		$this->form_validation->set_rules('status', 'Status Perkawinan', 'required|trim');
		$this->form_validation->set_rules('gol_darah', 'Golongan Darah', 'required|trim');
		// $this->form_validation->set_rules('asal_rujukan', 'Asal Rujukan', 'required|trim');
		if($this->form_validation->run() == FALSE) {
			$this->load->view('layout/header', $data);
			$this->load->view('layout/sidebar');
			$this->load->view('admin/pasien/ubah', $data);
			$this->load->view('layout/footer');
		} else {
			$id = $this->input->post('id_pasien');
			$data = [
				'no_rm' => html_escape($this->input->post('no_rm', true)),
				'nama_pasien' => html_escape($this->input->post('nama', true)),
				'tempat_lahir' => html_escape($this->input->post('tempat_lahir', true)),
				'tanggal_lahir' => html_escape($this->input->post('tgl', true)),
				'jk_pasien' => html_escape($this->input->post('jk', true)),
				'umur_pasien' => html_escape($this->input->post('umur', true)),
				'pendidikan' => html_escape($this->input->post('pendidikan', true)),
				'agama' => html_escape($this->input->post('agama', true)),
				'pekerjaan' => html_escape($this->input->post('pekerjaan', true)),
				'alamat' => html_escape($this->input->post('alamat', true)),
				'kecamatan' => html_escape($this->input->post('kecamatan', true)),
				'kelurahan' => html_escape($this->input->post('kelurahan', true)),
				'kabupaten' => html_escape($this->input->post('kabupaten', true)),
				'status' => html_escape($this->input->post('status', true)),
				'gol_darah' => html_escape($this->input->post('gol_darah', true))
				// 'asal_rujukan' => html_escape($this->input->post('asal_rujukan', true))
			];
			$this->Pasien_m->ubahDataPasien($data, $id);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert"><i class="fas fa-info-circle"></i> Pasien Berhasil Diubah.</div>');
			redirect('admin/pasien');
		}
	}

	public function hapus($id)
	{
		$this->db->delete('pasien', ['id_pasien' => $id]);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert"><i class="fas fa-info-circle"></i> Pasien Berhasil Dihapus.</div>');
		redirect('admin/pasien');
	}

	public function filter()
	{
		$data['title'] = 'Laporan Pasien';
		$this->load->view('layout/header', $data);
		$this->load->view('admin/pasien/filter');
		$this->load->view('layout/footer');
	}

	public function laporan()
	{
		$gender = @$_GET["jk"];
		$data['filter'] = "Gender : ".($gender=="L"? "Laki - Laki" : ($gender=="P"? "Perempuan" : "Laki-laki & Perempuan"));
		$data['pasien'] = $this->Pasien_m->get_filter('pasien', $gender)->result_array();
		$this->load->view('layout/header', $data);
		$this->load->view('admin/laporan/laporan_pasien');
		$this->load->view('layout/footer');
	}

}