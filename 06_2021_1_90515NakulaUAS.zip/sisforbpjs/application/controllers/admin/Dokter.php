<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dokter extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Dokter_m');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$page = @$_GET["page"]?@$_GET["page"]:1;
		$perpage = @$_GET["perpage"]?@$_GET["perpage"]:10;
		$data['rowcount']=$this->db->count_all_results('dokter');
		$data['title'] = 'Manajemen Data Dokter';
		$data['dokter'] = $this->Dokter_m->getPagination('dokter',$page,$perpage)->result_array();
		$this->form_validation->set_rules('nip', 'NIP', 'required|trim');
		$this->form_validation->set_rules('nama', 'Nama Dokter', 'required|trim');
		$this->form_validation->set_rules('tempat_lahir', 'Tempat Lahir', 'required|trim');
		$this->form_validation->set_rules('tgl', 'Tanggal Lahir', 'required|trim');
		$this->form_validation->set_rules('jk', 'Kelamin Dokter', 'required|trim');
		$this->form_validation->set_rules('jabatan', 'Jabatan', 'required|trim');
		$this->form_validation->set_rules('pendidikan', 'Pendidikan', 'required|trim');
		$this->form_validation->set_rules('spesialis', 'Spesialis', 'required|trim');
		if($this->form_validation->run() == FALSE) {
			$this->load->view('layout/header', $data);
			$this->load->view('layout/sidebar');
			$this->load->view('admin/dokter/index');
			$this->load->view('layout/footer');
		} else {
			$data = [
				'nip' => html_escape($this->input->post('nip', true)),
				'nama_dokter' => html_escape($this->input->post('nama', true)),
				'tempat_Lahir' => html_escape($this->input->post('tempat_lahir', true)),
				'tanggal_lahir' => html_escape($this->input->post('tgl', true)),
				'jk_dokter' => html_escape($this->input->post('jk', true)),
				'jabatan' => html_escape($this->input->post('jabatan', true)),
				'pendidikan' => html_escape($this->input->post('pendidikan', true)),
				'spesialis' => html_escape($this->input->post('spesialis', true))
			];
			$this->Dokter_m->tambahDataDokter($data);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert"><i class="fas fa-info-circle"></i> Dokter Berhasil Ditambahkan.</div>');
			redirect('admin/dokter');
		}
	}

	public function ubah($id)
	{
		$data['title'] = 'Ubah Data Dokter';
		$where = ['id_dokter' => $id];
		$data['dokter'] = $this->Dokter_m->get_where('dokter', $where)->row_array();
		$this->form_validation->set_rules('nip', 'NIP', 'required|trim');
		$this->form_validation->set_rules('nama', 'Nama Dokter', 'required|trim');
		$this->form_validation->set_rules('tempat_lahir', 'Tempat Lahir', 'required|trim');
		$this->form_validation->set_rules('tgl', 'Tanggal Lahir', 'required|trim');
		$this->form_validation->set_rules('jk', 'Kelamin Dokter', 'required|trim');
		$this->form_validation->set_rules('jabatan', 'Jabatan', 'required|trim');
		$this->form_validation->set_rules('pendidikan', 'Pendidikan', 'required|trim');
		$this->form_validation->set_rules('spesialis', 'Spesialis', 'required|trim');
		if($this->form_validation->run() == FALSE) {
			$this->load->view('layout/header', $data);
			$this->load->view('layout/sidebar');
			$this->load->view('admin/dokter/ubah');
			$this->load->view('layout/footer');
		} else {
			$id = $this->input->post('id_dokter');
			$data = [
				'nip' => $this->input->post('nip', true),
				'nama_dokter' => $this->input->post('nama', true),
				'tempat_lahir' => $this->input->post('tempat_lahir', true),
				'tanggal_lahir' => $this->input->post('tgl', true),
				'jk_dokter' => $this->input->post('jk', true),
				'jabatan' => $this->input->post('jabatan', true),
				'pendidikan' => $this->input->post('pendidikan', true),
				'spesialis' => $this->input->post('spesialis', true)
			];
			$this->Dokter_m->ubahDataDokter($data, $id);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert"><i class="fas fa-info-circle"></i> Dokter Berhasil Diubah.</div>');
			redirect('admin/dokter');
		}
	}

	public function hapus($id)
	{
		$this->db->delete('dokter', ['id_dokter' => $id]);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert"><i class="fas fa-info-circle"></i> Dokter Berhasil Dihapus.</div>');
		redirect('admin/dokter');
	}

	public function filter()
	{
		$data['title'] = 'Laporan Dokter';
		$this->load->view('layout/header', $data);
		$this->load->view('admin/dokter/filter');
		$this->load->view('layout/footer');
	}

	public function laporan()
	{
		$gender = @$_GET["jk"];
		$data['filter'] = "Gender : ".($gender=="L"? "Laki - Laki" : ($gender=="P"? "Perempuan" : "Laki-laki & Perempuan"));
		$data['dokter'] = $this->Dokter_m->get_filter('dokter', $gender)->result_array();
		$this->load->view('layout/header', $data);
		$this->load->view('admin/laporan/laporan_dokter');
		$this->load->view('layout/footer');
	}

}