<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?= $title; ?></h1>
  </div>
  <?= form_open('laporan/kunjunganpdf', 'method="get"'); ?>
    <div class="row mb-2">
      <div class="form-group col">
        <label for="tgl">Tanggal Kunjungan</label>
        <input type="date" name="tgl1" id="tgl1" class="form-control" value="<?=date('Y-m-d',  strtotime('-7 days'))?>">
        <small class="muted text-danger"></small>
      </div>
      <div class="form-group col">
        <label for="tgl">Tanggal Kunjungan</label>
        <input type="date" name="tgl2" id="tgl2" class="form-control" value="<?=date('Y-m-d')?>">
        <small class="muted text-danger"></small>
      </div>
      <div class="col d-flex align-items-center">
        <button class="btn btn-secondary"><i class="fas fa-print"></i></button>
      </div>
    </div>
  <?= form_close(); ?>
</main>