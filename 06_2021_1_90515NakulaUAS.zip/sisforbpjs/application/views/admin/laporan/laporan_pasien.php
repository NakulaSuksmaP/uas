<div class="container-fluid">
<!-- <h3 class="text-center">Sistem Informasi Peserta BPJS Kesehatan</h3> -->
  <h4 class="text-center">Laporan Pasien</h4>
  <h5 class="text-center"><?=$filter?></h5>
	<small class="text-center">Jl. Raya Dharma Husada Indah No.2</small>
	<div class="row">
		<div class="col-md">
			<table class="table text-center">
				<tr>
					<th>No</th>
					<th>No. RM</th>
					<th>Nama Pasien</th>
					<th>Tempat Lahir</th>
					<th>Tanggal Lahir</th>
					<th>Kelamin</th>
					<th>Umur</th>
					<th>Pendidikan</th>
					<th>Agama</th>
					<th>Pekerjaan</th>
					<th>Alamat</th>
					<th>Kecamatan</th>
					<th>Kelurahan</th>
					<th>Kabupaten/Kota</th>
					<th>Status</th>
					<th>Gol. Darah</th>
				</tr>
				<?php $no = 1; foreach($pasien as $d) : ?>
					<tr>
						<td><?= $no++; ?></td>
						<td><?= $d['no_rm']; ?></td>
						<td><?= $d['nama_pasien']; ?></td>
						<td><?= $d['tempat_lahir']; ?></td>
						<td><?= $d['tanggal_lahir']; ?></td>
						<td><?= $d['jk_pasien'] == 'L' ? 'Laki-Laki' : 'Perempuan'; ?></td>
						<td><?= $d['umur_pasien']; ?></td>
						<td><?= $d['pendidikan']; ?></td>
						<td><?= $d['agama']; ?></td>
						<td><?= $d['pekerjaan']; ?></td>
						<td><?= $d['alamat']; ?></td>
						<td><?= $d['kecamatan']; ?></td>
						<td><?= $d['kelurahan']; ?></td>
						<td><?= $d['kabupaten']; ?></td>
						<td><?= $d['status']; ?></td>
						<td><?= $d['gol_darah']; ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4 offset-md-8">
			<table>
				<tr>
					<td></td>
					<td>
						<?php $tgl = date_create(date('d-m-Y')); ?>
						<p>Surabaya, <?= date_format($tgl, 'd M Y'); ?>
							<br>
							Administrator <br><br>
							______________________
						</p>
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>

<script>
	window.print();
</script>