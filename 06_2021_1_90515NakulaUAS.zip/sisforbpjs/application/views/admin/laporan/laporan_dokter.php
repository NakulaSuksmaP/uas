<div class="container-fluid">
<!-- <h3 class="text-center">Sistem Informasi Peserta BPJS Kesehatan</h3> -->
  <h4 class="text-center">Laporan Dokter</h4>
  <h5 class="text-center"><?=$filter?></h5>
	<small class="text-center">Jl. Raya Dharma Husada Indah No.2</small>
	<div class="row">
		<div class="col-md">
			<table class="table text-center">
				<tr>
					<th>No</th>
					<th>NIP</th>
					<th>Nama Dokter</th>
					<th>Tempat Lahir</th>
					<th>Tanggal Lahir</th>
					<th>Kelamin</th>
					<th>Jabatan</th>
					<th>Pendidikan</th>
					<th>Spesialis</th>
				</tr>
				<?php $no = 1; foreach($dokter as $d) : ?>
					<tr>
						<td><?= $no++; ?></td>
						<td><?= $d['nip']; ?></td>
						<td><?= $d['nama_dokter']; ?></td>
						<td><?= $d['tempat_lahir']; ?></td>
						<td><?= $d['tanggal_lahir']; ?></td>
						<td><?= $d['jk_dokter']; ?></td>
						<td><?= $d['jabatan']; ?></td>
						<td><?= $d['pendidikan']; ?></td>
						<td><?= $d['spesialis']; ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4 offset-md-8">
			<table>
				<tr>
					<td></td>
					<td>
						<?php $tgl = date_create(date('d-m-Y')); ?>
						<p>Surabaya, <?= date_format($tgl, 'd M Y'); ?>
							<br>
							Administrator <br><br>
							______________________
						</p>
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>

<script>
	window.print();
</script>