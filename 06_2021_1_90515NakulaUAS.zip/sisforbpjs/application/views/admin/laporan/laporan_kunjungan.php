<div class="container-fluid">
	<!-- <h3 class="text-center">Sistem Informasi Peserta BPJS Kesehatan</h3> -->
  <h4 class="text-center"><?=$title?></h4>
  <h5 class="text-center"><?=$filter?></h5>
	<small class="text-center">Jl. Raya Dharma Husada Indah No.2</small>
	<div class="row">
		<div class="col-md">
			<table class="table table-striped">
        <thead>
          <tr>
            <td>No</td>
            <td>Tanggal</td>
            <td>No RM</td>
            <td>Pasien</td>
            <td>Umur</td>
            <td>Jenis Kelamin</td>
            <!-- <td>Keluhan</td> -->
            <td>Poliklinik</td>
            <td>Peserta</td>
            <td>Asal Rujukan</td>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; foreach($kunjungan as $u) : ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= $u['tgl_berobat']; ?></td>
              <td><?= $u['no_rm']; ?></td>
              <td><?= $u['nama_pasien']; ?></td>
              <td><?= $u['umur_pasien']; ?></td>
              <td><?= $u['jk_pasien'] == 'L' ? 'Laki-Laki' : 'Perempuan'; ?></td>
              <!-- <td><?= $u['keluhan']; ?></td> -->
              <td><?= $u['diagnosa']; ?></td>
              <td><?= $u['peserta']; ?></td>
              <td><?= $u['penatalaksaan']; ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4 offset-md-8">
			<table>
				<tr>
					<td></td>
					<td>
						<?php $tgl = date_create(date('d-m-Y')); ?>
						<p>Surabaya, <?= date_format($tgl, 'd M Y'); ?>
							<br>
							Administrator <br><br>
							______________________
						</p>
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>

<script>
	window.print();
</script>