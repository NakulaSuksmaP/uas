<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?= $title; ?></h1>
  </div>
  <?= form_open('laporan/pasienpdf', 'method="get"'); ?>
    <div class="row mb-2">
      <div class="form-group col">
        <label for="jk">Jenis Kelamin</label>
        <select name="jk" id="jk" class="form-control">
          <option value="A">-- Pilih Jenis Kelamin --</option>
          <option value="A">Semua</option>
          <option value="L">Laki-Laki</option>
          <option value="P">Perempuan</option>
        </select>
      </div>
      <div class="col d-flex align-items-center">
        <button class="btn btn-secondary"><i class="fas fa-print"></i></button>
      </div>
    </div>
  <?= form_close(); ?>
</main>