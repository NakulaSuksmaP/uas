<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?= $title; ?></h1>
  </div>
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <?= form_open('admin/pasien/ubah/'. $pasien['id_pasien']); ?>
          <input type="hidden" name="id_pasien" class="form-control" value="<?= $pasien['id_pasien']; ?>">
          <div class="form-group">
            <label for="no_rm">No. RM</label>
            <input type="text" name="no_rm" id="no_rm" class="form-control" value="<?= $pasien['no_rm']; ?>">
            <small class="muted text-danger"><?= form_error('no_rm'); ?></small>
          </div>
          <div class="form-group">
            <label for="nama">Nama Pasien</label>
            <input type="text" name="nama" id="nama" class="form-control" value="<?= $pasien['nama_pasien']; ?>">
            <small class="muted text-danger"><?= form_error('nama'); ?></small>
          </div>
          <div class="form-group">
            <label for="tempat_lahir">Tempat Lahir</label>
            <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control" value="<?= $pasien['tempat_lahir']; ?>">
            <small class="muted text-danger"><?= form_error('tempat_lahir'); ?></small>
          </div>
          <div class="form-group">
            <label for="tgl">Tanggal Lahir</label>
            <input type="date" name="tgl" id="tgl" class="form-control" value="<?= $pasien['tanggal_lahir']; ?>">
            <small class="muted text-danger"><?= form_error('tgl'); ?></small>
          </div>
          <div class="form-group">
            <label for="jk">Jenis Kelamin</label>
            <select name="jk" id="jk" class="form-control">
              <option value="">-- Pilih Jenis Kelamin --</option>
                <option value="L" <?php if($pasien['jk_pasien'] == 'L'){echo "selected";} ?>>Laki-Laki</option>
                <option value="P" <?php if($pasien['jk_pasien'] == 'P'){echo "selected";} ?>>Perempuan</option>
            </select>
            <small class="muted text-danger"><?= form_error('jk'); ?></small>
          </div>
          <div class="form-group">
            <label for="umur">Umur</label>
            <input type="number" name="umur" id="umur" class="form-control" value="<?= $pasien['umur_pasien']; ?>">
            <small class="muted text-danger"><?= form_error('umur'); ?></small>
          </div>
          <div class="form-group">
            <label for="pendidikan">Pendidikan</label>
            <input type="text" name="pendidikan" id="pendidikan" class="form-control" value="<?= $pasien['pendidikan']; ?>">
            <small class="muted text-danger"><?= form_error('pendidikan'); ?></small>
          </div>
          <div class="form-group">
            <label for="agama">Agama</label>
            <input type="text" name="agama" id="agama" class="form-control" value="<?= $pasien['agama']; ?>">
            <small class="muted text-danger"><?= form_error('agama'); ?></small>
          </div>
          <div class="form-group">
            <label for="pekerjaan">Pekerjaan</label>
            <input type="text" name="pekerjaan" id="pekerjaan" class="form-control" value="<?= $pasien['pekerjaan']; ?>">
            <small class="muted text-danger"><?= form_error('pekerjaan'); ?></small>
          </div>
          <div class="form-group">
            <label for="alamat">Alamat</label>
            <input type="text" name="alamat" id="alamat" class="form-control" value="<?= $pasien['alamat']; ?>">
            <small class="muted text-danger"><?= form_error('alamat'); ?></small>
          </div>
          <div class="form-group">
            <label for="kecamatan">Kecamatan</label>
            <input type="text" name="kecamatan" id="kecamatan" class="form-control" value="<?= $pasien['kecamatan']; ?>">
            <small class="muted text-danger"><?= form_error('kecamatan'); ?></small>
          </div>
          <div class="form-group">
            <label for="kelurahan">Kelurahan</label>
            <input type="text" name="kelurahan" id="kelurahan" class="form-control" value="<?= $pasien['kelurahan']; ?>">
            <small class="muted text-danger"><?= form_error('kelurahan'); ?></small>
          </div>
          <div class="form-group">
            <label for="kabupaten">Kabupaten/Kota</label>
            <input type="text" name="kabupaten" id="kabupaten" class="form-control" value="<?= $pasien['kabupaten']; ?>">
            <small class="muted text-danger"><?= form_error('kabupaten'); ?></small>
          </div>
          <div class="form-group">
            <label for="status">Status Perkawinan</label>
            <input type="text" name="status" id="status" class="form-control" value="<?= $pasien['status']; ?>">
            <small class="muted text-danger"><?= form_error('status'); ?></small>
          </div>
          <div class="form-group">
            <label for="gol_darah">Golongan Darah</label>
            <input type="text" name="gol_darah" id="gol_darah" class="form-control" value="<?= $pasien['gol_darah']; ?>">
            <small class="muted text-danger"><?= form_error('gol_darah'); ?></small>
          </div>
          <!-- <div class="form-group">
            <label for="asal_rujukan">Asal Rujukan</label>
            <select name="asal_rujukan" id="asal_rujukan" class="form-control">
              <option value="">-- Pilih --</option>
                <option value="Dalam Kota" <?php if($pasien['asal_rujukan'] == 'Dalam Kota'){echo "selected";} ?>>Dalam Kota</option>
                <option value="Luar Kota" <?php if($pasien['asal_rujukan'] == 'Luar Kota'){echo "selected";} ?>>Luar Kota</option>
                <option value="Kabupaten" <?php if($pasien['asal_rujukan'] == 'Kabupaten'){echo "selected";} ?>>Kabupaten</option>
            </select>
            <small class="muted text-danger"><?= form_error('jk'); ?></small>
          </div> -->
          <div class="form-group">
            <button type="submit" class="btn btn-dark">Ubah</button>
          </div>
          <?= form_close(); ?> 
        </div>
      </div>
    </div>
  </div>
</main>