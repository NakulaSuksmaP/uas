<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?= $title; ?></h1>
  </div>
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <?= form_open('admin/dokter/ubah/'. $dokter['id_dokter']); ?>
          <input type="hidden" name="id_dokter" class="form-control" value="<?= $dokter['id_dokter']; ?>">
          <div class="form-group">
            <label for="nip">NIP</label>
            <input type="text" name="nip" id="nip" class="form-control" value="<?= $dokter['nip']; ?>">
            <small class="muted text-danger"><?= form_error('nip'); ?></small>
          </div>
          <div class="form-group">
            <label for="nama">Nama Dokter</label>
            <input type="text" name="nama" id="nama" class="form-control" value="<?= $dokter['nama_dokter']; ?>">
            <small class="muted text-danger"><?= form_error('nama'); ?></small>
          </div>
          <div class="form-group">
            <label for="tempat_lahir">Tempat Lahir</label>
            <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control" value="<?= $dokter['tempat_lahir']; ?>">
            <small class="muted text-danger"><?= form_error('tempat_lahir'); ?></small>
          </div>
          <div class="form-group">
            <label for="tgl">Tanggal Lahir</label>
            <input type="date" name="tgl" id="tgl" class="form-control" value="<?= $dokter['tanggal_lahir']; ?>">
            <small class="muted text-danger"><?= form_error('tgl'); ?></small>
          </div>
          <div class="form-group">
            <label for="jk">Jenis Kelamin</label>
            <select name="jk" id="jk" class="form-control">
              <option value="">-- Pilih Jenis Kelamin --</option>
                <option value="L" <?php if($dokter['jk_dokter'] == 'L'){echo "selected";} ?>>Laki-Laki</option>
                <option value="P" <?php if($dokter['jk_dokter'] == 'P'){echo "selected";} ?>>Perempuan</option>
            </select>
            <small class="muted text-danger"><?= form_error('jk'); ?></small>
          </div>
          <div class="form-group">
            <label for="jabatan">Jabatan</label>
            <input type="text" name="jabatan" id="jabatan" class="form-control" value="<?= $dokter['jabatan']; ?>">
            <small class="muted text-danger"><?= form_error('jabatan'); ?></small>
          </div>
          <div class="form-group">
            <label for="pendidikan">Pendidikan</label>
            <input type="text" name="pendidikan" id="pendidikan" class="form-control" value="<?= $dokter['pendidikan']; ?>">
            <small class="muted text-danger"><?= form_error('pendidikan'); ?></small>
          </div>
          <div class="form-group">
            <label for="spesialis">Spesialis</label>
            <input type="text" name="spesialis" id="spesialis" class="form-control" value="<?= $dokter['spesialis']; ?>">
            <small class="muted text-danger"><?= form_error('spesialis'); ?></small>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-dark">Ubah</button>
          </div>
          <?= form_close(); ?> 
        </div>
      </div>
    </div>
  </div>
</main>