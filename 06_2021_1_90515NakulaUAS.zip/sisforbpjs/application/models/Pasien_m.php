<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien_m extends CI_Model {
	public function get($table)
	{
		return $this->db->get($table);
	}

	public function getPagination($table,$page,$perpage)
	{
		$offset = 0;
		if ($page > 1){
			$offset = ($perpage*($page-1));
		}
		return $this->db->get($table,$perpage,$offset);
	}

	public function get_filter($table, $gender)
	{
		if($gender!=="A")
			$this->db->where('jk_pasien', $gender);
		return $this->db->get($table);
	}

	public function get_where($table, $where)
	{
		return $this->db->get_where($table, $where);
	}

	public function tambahDataPasien($data)
	{
		$this->db->insert('pasien', $data);
	}

	public function ubahDataPasien($data, $id)
	{
		$this->db->where('id_pasien', $id);
		$this->db->update('pasien', $data);
	}

}